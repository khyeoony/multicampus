package project.service;

public class Criminal {

	public static void main(String[] args) {
		

	}

}
